package io.studyuk.view.list_bab.list_video

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import io.studyuk.R

class ListVideoActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list_video)
    }
}
