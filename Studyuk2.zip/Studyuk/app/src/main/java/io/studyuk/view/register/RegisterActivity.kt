package io.studyuk.view.register

import android.app.AlertDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import io.studyuk.R
import io.studyuk.view.main.MainActivity
import kotlinx.android.synthetic.main.activity_register.*

class RegisterActivity : AppCompatActivity() {
    private val TAG = "RegisterActivity"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)
        val db = Firebase.firestore

        btn_register.setOnClickListener {
            val name = et_name.text.toString()
            val email = et_email.text.toString()
            val grade = et_grade.text.toString()
            val password = et_password.text.toString()
            val repassword = et_repassword.text.toString()

            if (et_name.text.toString() != "" && et_email.text.toString() != "" && et_password.text.toString() != ""){
                val user = hashMapOf(
                    "name" to name,
                    "email" to email,
                    "grade" to grade,
                    "password" to password
                )

                db.collection("users")
                    .add(user)
                    .addOnSuccessListener { documentReference ->
                        Log.d(TAG, "DocumentSnapshot added with ID: ${documentReference.id}")

                    }
                    .addOnFailureListener { e ->
                        Log.w(TAG, "Error adding document", e)
                        showDialogError()
                    }

                startActivity(Intent(this, MainActivity::class.java))
                finishAffinity()
            } else {
                showDialog()
            }
        }
    }

    private fun showDialog() {
        AlertDialog.Builder(this)
            // Judul
            .setTitle("Error !")
            // Pesan yang di tamopilkan
            .setMessage("Semua field harus terisi!")
            .setPositiveButton("Ok") { dialogInterface, i ->
                dialogInterface.dismiss()
            }

            .show()
    }

    private fun showDialogError() {
        AlertDialog.Builder(this)
            // Judul
            .setTitle("Error !")
            // Pesan yang di tamopilkan
            .setMessage("Registrasi gagal!")
            .setPositiveButton("Ok") { dialogInterface, i ->
                dialogInterface.dismiss()
            }

            .show()
    }
}
